import os
import argparse 
import random
import torch
import pandas as pd
import numpy as np
import cv2
import gc
import shutil
from transformers import Qwen2VLForConditionalGeneration, AutoProcessor
from qwen_utils import process_vision_info
from pycocotools.coco import COCO
from tam import TAM
from metrics import calcola_metriche_tam, calcola_pixel_accuracy

# --- CONFIGURAZIONE ARGOMENTI DA RIGA DI COMANDO (CLI) ---
parser = argparse.ArgumentParser(description="Esegui test CoT Misto (75% Positivi, 25% Negativi) con analisi TAM.")
parser.add_argument(
    '-n', '--num_images', 
    type=int, 
    default=None, 
    help="Numero massimo di immagini da analizzare (es. -n 5)."
)
args = parser.parse_args()

# --- CONFIGURAZIONI INIZIALI ---
csv_path = './dataset.csv'
ann_file = './dataset/annotations/instances_val2017.json'
output_dir = './output/test_mixed_cot/'

tam_dir = os.path.join(output_dir, 'tam_heatmaps_cot')
os.makedirs(tam_dir, exist_ok=True)

results_file = os.path.join(output_dir, 'results_mixed_cot_75_25.csv') 

print("Inizializzo COCO e le categorie...")
coco = COCO(ann_file)
df = pd.read_csv(csv_path)

cats = coco.loadCats(coco.getCatIds())
tutte_le_categorie = {cat['id']: cat['name'] for cat in cats}

if args.num_images is not None:
    df = df.head(args.num_images)
    print(f"\n[INFO] 🛠️ Modalità Test CLI: Elaborazione limitata alle prime {args.num_images} immagini!\n")

print("Carico il modello Qwen2-VL (versione CPU)...")
model_name = "Qwen/Qwen2-VL-2B-Instruct"
processor = AutoProcessor.from_pretrained(model_name)
model = Qwen2VLForConditionalGeneration.from_pretrained(
    model_name, device_map="cpu", torch_dtype=torch.float32, low_cpu_mem_usage=True
)

special_ids = {'img_id': [151652, 151653],
               'prompt_id': [151653, [151645, 198, 151644, 77091]],
               'answer_id': [[198, 151644, 77091, 198], -1]}

risultati = []

# --- VARIABILI PER METRICHE GLOBALI ---
SOGLIA_IOU_CORRETTO = 0.3

# Tracker Positive Queries (CoT)
Pos_TP = 0  
Pos_FP = 0  
Pos_FN = 0  
Tot_Pos = 0

# Tracker Negative Queries (CoT)
Neg_TN = 0  
Neg_FP = 0  
Tot_Neg = 0

lista_obj_iou = []

# --- CICLO SULLE IMMAGINI ---
for index, row in df.iterrows():
    img_id = row['img_id']
    img_path = os.path.join(output_dir, row['path'])
    obj_main = row['obj_main']
    ann_id_main = row['ann_id_main']
    
    # --- LOGICA DI CAMPIONAMENTO 75% POSITIVI / 25% NEGATIVI ---
    is_positive_query = random.random() < 0.75
    
    if is_positive_query:
        target_obj = obj_main
        query_type = "Positive"
        Tot_Pos += 1
    else:
        ann_ids_immagine = coco.getAnnIds(imgIds=img_id)
        anns_immagine = coco.loadAnns(ann_ids_immagine)
        id_categorie_presenti = set([ann['category_id'] for ann in anns_immagine])
        
        id_categorie_assenti = [cat_id for cat_id in tutte_le_categorie.keys() if cat_id not in id_categorie_presenti]
        fake_obj_id = random.choice(id_categorie_assenti)
        target_obj = tutte_le_categorie[fake_obj_id]
        query_type = "Negative"
        Tot_Neg += 1
    
    print(f"\n[{index+1}/{len(df)}] Immagine: {row['path']} | Query: {query_type} | Target: {target_obj}")
    
    prompt = f"Is there a {target_obj} in this image? Let's think step by step before answering."
    system_prompt = "You are an AI detective. You must observe the image in detail, list what you see, and logically deduce whether the specified object is present."

    messages = [
        {"role": "system", "content": [{"type": "text", "text": system_prompt}]},
        {"role": "user", "content": [{"type": "image", "image": img_path}, {"type": "text", "text": prompt}]}
    ]    
    
    text = processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    image_inputs, video_inputs = process_vision_info(messages)
    
    inputs = processor(text=[text], images=image_inputs, videos=video_inputs, padding=True, return_tensors="pt")
    inputs = inputs.to(model.device)
    
    with torch.no_grad():
        outputs = model.generate(
            **inputs, 
            max_new_tokens=150, 
            do_sample=True,
            temperature=0.7,
            use_cache=True, 
            output_hidden_states=True, 
            return_dict_in_generate=True
        )
        
    generated_ids = outputs.sequences
    testo_generato = processor.decode(generated_ids[0][inputs['input_ids'].shape[1]:], skip_special_tokens=True).strip()
    print(f"   -> Ragionamento del modello:\n      {testo_generato}\n")
    
    testo_pulito = testo_generato.lower()
    parole_generate = [ "".join(c for c in p if c.isalpha()) for p in testo_pulito.split() ]
    
    ha_detto_yes = "yes" in parole_generate
    ha_detto_no = "no" in parole_generate
    
    logits = [model.lm_head(feats[-1]) for feats in outputs.hidden_states]
    token_ids_generati = generated_ids[0][inputs['input_ids'].shape[1]:].cpu().tolist()
    
    # --- VALUTAZIONE COVERTITA IN BASE AL TIPO DI QUERY ---
    
    if query_type == "Positive":
        if ha_detto_no and not ha_detto_yes:
            print("   [-] FALSO NEGATIVO (FN): Il modello ha escluso un oggetto realmente presente.")
            Pos_FN += 1
            
            risultati.append({
                'img_id': img_id, 'query_type': query_type, 'target_obj': target_obj, 
                'prompt': prompt, 'output': testo_generato.replace('\n', ' '), 
                'target_token': 'NONE', 'token_index': -1, 'obj_iou': 0.0, 'is_correct_id': 0
            })
        else:
            # Identificazione positiva: estraiamo i token dell'oggetto o del yes nel CoT
            target_indices = []
            target_token_texts = []
            
            for i, t_id in enumerate(token_ids_generati):
                parola_token = processor.decode([t_id]).strip().lower()
                parola_pulita = "".join(c for c in parola_token if c.isalpha())
                if parola_pulita == "yes" or (target_obj.lower() in parola_pulita and len(parola_pulita) > 1):
                    target_indices.append(i)
                    target_token_texts.append(parola_token)
            
            if not target_indices:
                target_indices.append(len(token_ids_generati) - 1)
                target_token_texts.append(processor.decode([token_ids_generati[-1]]).strip())
                
            # Caricamento Ground Truth reale da COCO
            ann = coco.loadAnns(ann_id_main)[0]
            maschera_coco = coco.annToMask(ann) 
            vision_shape = (inputs['image_grid_thw'][0, 1] // 2, inputs['image_grid_thw'][0, 2] // 2)
            
            # Generazione mappe TAM per ogni punto di attivazione nel CoT
            for t_idx, t_text in zip(target_indices, target_token_texts):
                base_name, ext = os.path.splitext(row['path'])
                percorso_salvataggio = os.path.join(tam_dir, f"{base_name}_pos_step{t_idx}_{target_obj.replace(' ', '_')}{ext}")
                heatmap = TAM(generated_ids[0].cpu().tolist(), vision_shape, logits, special_ids, image_inputs, processor, percorso_salvataggio, t_idx, [], False)
                
                heatmap_norm = cv2.cvtColor(heatmap, cv2.COLOR_BGR2GRAY).astype(np.float32) / 255.0 if len(heatmap.shape) == 3 else heatmap.astype(np.float32)
                obj_iou, _, _ = calcola_metriche_tam(heatmap_norm, maschera_coco)
                lista_obj_iou.append(obj_iou)
                
                is_correct_id = 0
                if obj_iou >= SOGLIA_IOU_CORRETTO:
                    print(f"      [+] VERO POSITIVO (TP) sull'attivazione '{t_text}'! (IoU: {obj_iou:.3f})")
                    Pos_TP += 1
                    is_correct_id = 1
                else:
                    print(f"      [!] FALSO POSITIVO (FP_loc) - Errore localizzazione su '{t_text}'. (IoU: {obj_iou:.3f})")
                    Pos_FP += 1
                    
                risultati.append({
                    'img_id': img_id, 'query_type': query_type, 'target_obj': target_obj, 
                    'prompt': prompt, 'output': testo_generato.replace('\n', ' '), 
                    'target_token': t_text, 'token_index': t_idx, 'obj_iou': round(obj_iou, 4), 'is_correct_id': is_correct_id
                })

    elif query_type == "Negative":
        if ha_detto_no and not ha_detto_yes:
            print("   [+] VERO NEGATIVO (TN): Il CoT ha aiutato il modello a escludere l'oggetto falso.")
            Neg_TN += 1
            
            risultati.append({
                'img_id': img_id, 'query_type': query_type, 'target_obj': target_obj, 
                'prompt': prompt, 'output': testo_generato.replace('\n', ' '), 
                'target_token': 'NONE', 'token_index': -1, 'obj_iou': 0.0, 'is_correct_id': 0
            })
        else:
            print("   [!] ALLUCINAZIONE (FP_alluc): Il modello si è autoconvinto che l'oggetto ci sia.")
            Neg_FP += 1
            
            target_indices = []
            target_token_texts = []
            
            for i, t_id in enumerate(token_ids_generati):
                parola_token = processor.decode([t_id]).strip().lower()
                parola_pulita = "".join(c for c in parola_token if c.isalpha())
                if parola_pulita == "yes" or (target_obj.lower() in parola_pulita and len(parola_pulita) > 1):
                    target_indices.append(i)
                    target_token_texts.append(parola_token)
            
            # Nei negativi con CoT prendiamo solo l'ultima attivazione (la conclusione dell'errore)
            if target_indices:
                target_indices = [target_indices[-1]]
                target_token_texts = [target_token_texts[-1]]
            else:
                target_indices.append(len(token_ids_generati) - 1)
                target_token_texts.append(processor.decode([token_ids_generati[-1]]).strip())
                
            vision_shape = (inputs['image_grid_thw'][0, 1] // 2, inputs['image_grid_thw'][0, 2] // 2)
            
            for t_idx, t_text in zip(target_indices, target_token_texts):
                base_name, ext = os.path.splitext(row['path'])
                percorso_salvataggio = os.path.join(tam_dir, f"{base_name}_hallucination_step{t_idx}_{target_obj.replace(' ', '_')}{ext}")
                heatmap = TAM(generated_ids[0].cpu().tolist(), vision_shape, logits, special_ids, image_inputs, processor, percorso_salvataggio, t_idx, [], False)
                
                risultati.append({
                    'img_id': img_id, 'query_type': query_type, 'target_obj': target_obj, 
                    'prompt': prompt, 'output': testo_generato.replace('\n', ' '), 
                    'target_token': t_text, 'token_index': t_idx, 'obj_iou': 0.0, 'is_correct_id': 0
                })

    # --- RESET PROFONDO MEMORIA CPU ---
    del inputs, image_inputs, video_inputs, outputs, generated_ids, logits
    if 'heatmap' in locals(): del heatmap
    if 'maschera_coco' in locals(): del maschera_coco
    gc.collect()

    df_temp = pd.DataFrame(risultati)
    df_temp.to_csv(results_file, index=False)

# --- CALCOLO METRICHE FINALI DI SINTESI ---
print("\n" + "="*60)
print("🎯 REPORT METRICHE GLOBALI CoT: ESPERIMENTO MISTO 75-25")
print("="*60)

Tot_Pos_Attivazioni = Pos_TP + Pos_FP + Pos_FN
Sensitivity = Pos_TP / Tot_Pos if Tot_Pos > 0 else 0
Specificity = Neg_TN / Tot_Neg if Tot_Neg > 0 else 0
Hallucination_Rate = Neg_FP / Tot_Neg if Tot_Neg > 0 else 0
Global_Acc = (Pos_TP + Neg_TN) / (Tot_Pos + Tot_Neg) if (Tot_Pos + Tot_Neg) > 0 else 0
m_IoU_Positive = np.mean(lista_obj_iou) if lista_obj_iou else 0

dati_statistici = [
    {'img_id': '---', 'query_type': '--- STATISTICHE FINALI ---', 'target_obj': '---', 'prompt': '', 'output': '', 'target_token': '', 'token_index': '', 'obj_iou': '', 'is_correct_id': ''},
    {'img_id': 'Immagini Totali', 'query_type': str(Tot_Pos + Tot_Neg), 'target_obj': f"Pos: {Tot_Pos} | Neg: {Tot_Neg}", 'prompt': '', 'output': '', 'target_token': '', 'token_index': '', 'obj_iou': '', 'is_correct_id': ''},
    {'img_id': '--- RISULTATI SU POSITIVE QUERIES ---', 'query_type': '---', 'target_obj': '---', 'prompt': '', 'output': '', 'target_token': '', 'token_index': '', 'obj_iou': '', 'is_correct_id': ''},
    {'img_id': 'True Negatives (FN) - Modello dice No', 'query_type': str(Pos_FN), 'target_obj': '', 'prompt': '', 'output': '', 'target_token': '', 'token_index': '', 'obj_iou': '', 'is_correct_id': ''},
    {'img_id': 'Mappe True Positives (TP)', 'query_type': str(Pos_TP), 'target_obj': '', 'prompt': '', 'output': '', 'target_token': '', 'token_index': '', 'obj_iou': '', 'is_correct_id': ''},
    {'img_id': 'Mappe False Positives (FP_loc)', 'query_type': str(Pos_FP), 'target_obj': '', 'prompt': '', 'output': '', 'target_token': '', 'token_index': '', 'obj_iou': '', 'is_correct_id': ''},
    {'img_id': 'Sensitivity / Recall (Su Immagini)', 'query_type': f"{Sensitivity:.2%}", 'target_obj': '', 'prompt': '', 'output': '', 'target_token': '', 'token_index': '', 'obj_iou': '', 'is_correct_id': ''},
    {'img_id': 'Media IoU (Solo Attivazioni Positive)', 'query_type': f"{m_IoU_Positive:.4f}", 'target_obj': '', 'prompt': '', 'output': '', 'target_token': '', 'token_index': '', 'obj_iou': '', 'is_correct_id': ''},
    {'img_id': '--- RISULTATI SU NEGATIVE QUERIES ---', 'query_type': '---', 'target_obj': '---', 'prompt': '', 'output': '', 'target_token': '', 'token_index': '', 'obj_iou': '', 'is_correct_id': ''},
    {'img_id': 'True Negatives (TN) - Rifiuto Falso', 'query_type': str(Neg_TN), 'target_obj': '', 'prompt': '', 'output': '', 'target_token': '', 'token_index': '', 'obj_iou': '', 'is_correct_id': ''},
    {'img_id': 'False Positives (FP_alluc) - Allucinazione', 'query_type': str(Neg_FP), 'target_obj': '', 'prompt': '', 'output': '', 'target_token': '', 'token_index': '', 'obj_iou': '', 'is_correct_id': ''},
    {'img_id': 'Specificity', 'query_type': f"{Specificity:.2%}", 'target_obj': '', 'prompt': '', 'output': '', 'target_token': '', 'token_index': '', 'obj_iou': '', 'is_correct_id': ''},
    {'img_id': 'Hallucination Rate (CoT)', 'query_type': f"{Hallucination_Rate:.2%}", 'target_obj': '', 'prompt': '', 'output': '', 'target_token': '', 'token_index': '', 'obj_iou': '', 'is_correct_id': ''},
    {'img_id': '--- SINTESI GLOBALE ---', 'query_type': '---', 'target_obj': '---', 'prompt': '', 'output': '', 'target_token': '', 'token_index': '', 'obj_iou': '', 'is_correct_id': ''},
    {'img_id': 'Accuratezza Bilanciata (Decisionale)', 'query_type': f"{Global_Acc:.2%}", 'target_obj': '', 'prompt': '', 'output': '', 'target_token': '', 'token_index': '', 'obj_iou': '', 'is_correct_id': ''}
]

risultati_completi = risultati + dati_statistici
df_finale = pd.DataFrame(risultati_completi)
df_finale.to_csv(results_file, index=False)

# --- CREAZIONE ZIP FINALE ---
nome_prompt = "Mixed_75_25_CoT"
suffisso_img = f"_{len(df)}img" if args.num_images else "_Full"
nome_zip = f"Test_{nome_prompt}{suffisso_img}"
shutil.make_archive(os.path.join(os.path.dirname(os.path.normpath(output_dir)), nome_zip), 'zip', output_dir)
print(f"[SUCCESSO] L'archivio {nome_zip}.zip è pronto!")